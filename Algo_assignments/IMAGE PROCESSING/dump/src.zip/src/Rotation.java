
 /* Rotation of an image
 * by jannatun Nahar
 */
import java.awt.GridLayout;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Rotation extends JFrame {
	
	private static final long serialVersionUID = 1L;
	private static Scanner sc;
	
	Rotation(String in, String out){
        super("..:: Image Rotation ::..");
        try {
            this.setLayout(new GridLayout(1, 2, 10, 10));
            JPanel pic1 = new JPanel();
            JPanel pic2 = new JPanel();
            File f1 = new File(in);
            File f2 = new File(out);
            
            BufferedImage picture1 = ImageIO.read(f1);
            pic1.add(new JLabel(new ImageIcon(picture1)));
            BufferedImage picture2 = RotationProcess(picture1);
            ImageIO.write(picture2, "jpg", f2);
            pic2.add(new JLabel(new ImageIcon(picture2)));
            this.add(pic1);
            this.add(pic2);
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }
	  
	
	BufferedImage RotationProcess(BufferedImage src)
	{
		BufferedImage newPic = new BufferedImage(src.getWidth(), src.getHeight(), BufferedImage.TYPE_3BYTE_BGR);
		int width = src.getWidth();
        int height = src.getHeight();
        
        System.out.println("Enter the angle to rotate: ");
         sc = new Scanner(System.in);
        String p =sc.nextLine();
        
        double angle = Math.toRadians(Double.parseDouble(p));
        double sin = Math.sin(angle);
        double cos = Math.cos(angle);
        double x0 = 0.5 * (width  - 1);    
        double y0 = 0.5 * (height - 1); 
        
        for (int x = 0; x < width; x++) 
        {
            for (int y = 0; y < height; y++) 
            {
                double a = x - x0;
                double b = y - y0;
                int xx = (int) (+a * cos - b * sin + x0);
                int yy = (int) (+a * sin + b * cos + y0);

                
                if (xx >= 0 && xx < width && yy >= 0 && yy < height) 
                {
                newPic.setRGB(x, y, src.getRGB(xx, yy));    
                }
            }
        }
		return newPic;
	}
	
	 public static void main(String args[])throws IOException
	 
    {
		 	Rotation rot = new Rotation("nature.jpg", "output");
            rot.setSize(1024, 500);
            rot.setVisible(true);
            rot.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);       
                
    }
 

}
