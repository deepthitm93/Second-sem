
/*
 * Smoothing of an Image
 * by Jannatun Nahar
 */
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JFrame;

public class SmoothingImage extends JFrame
{
	
	private static final long serialVersionUID = 1L;
	static int[][][] rgb_buffer;
	SmoothingImage(String in, String out)
	{
        super("..:: Smoothing of an Image ::..");
try {
    this.setLayout(new GridLayout(1, 2, 10, 10));
    JPanel img1 = new JPanel();
    JPanel img2 = new JPanel();
    File f1 = new File(in);
    File f2 = new File(out);
    BufferedImage image1 = ImageIO.read(f1);
    img1.add(new JLabel(new ImageIcon(image1)));
    BufferedImage image2 = SmoothingProcess(image1);
    ImageIO.write(image2, "jpg", f2);
    img2.add(new JLabel(new ImageIcon(image2)));
    this.add(img1);
    this.add(img2);
} catch (Exception ex) {
    System.out.println(ex.getMessage());
}
 }
	
	 BufferedImage SmoothingProcess(BufferedImage src) 
	 {
		 BufferedImage SmoothPic = new BufferedImage(src.getWidth(), src.getHeight(), BufferedImage.TYPE_3BYTE_BGR);
		 
		 rgb_buffer = new int[3][src.getHeight()][src.getWidth()];
	     
	     for (int row = 0; row < src.getHeight(); row++) 
	     {
	         for (int col = 0; col <src.getWidth(); col++) 
	         {
	        	
	        	 Color c1= new Color(src.getRGB(col, row));
	        	 
	        	 rgb_buffer[0][row][col] =c1.getRed();
	        	 rgb_buffer[1][row][col] =c1.getGreen();
	        	 rgb_buffer[2][row][col] =c1.getBlue();
	        	 
	         }
	     }
	     
	     for (int x = 1; x < src.getHeight()-1; x++) {
	         for (int y = 1; y <src.getWidth()-1; y++) {
	        	 
	        	 int r =  rgb_buffer[0][x-1][y-1]+rgb_buffer[0][x-1][y]+rgb_buffer[0][x-1][y+1]+
	        			  rgb_buffer[0][x][y-1]+ rgb_buffer[0][x][y]+rgb_buffer[0][x][y+1]+
	        			  rgb_buffer[0][x+1][y-1]+rgb_buffer[0][x+1][y]+rgb_buffer[0][x+1][y+1];

	        	 int g =  rgb_buffer[1][x-1][y-1]+rgb_buffer[1][x-1][y]+ rgb_buffer[1][x-1][y+1]+
	        			 rgb_buffer[1][x][y-1]+rgb_buffer[1][x][y]+rgb_buffer[1][x][y+1]+
	        			 rgb_buffer[1][x+1][y-1]+rgb_buffer[1][x+1][y]+ rgb_buffer[1][x+1][y+1];
	        			  
          	 int b =  rgb_buffer[2][x-1][y-1]+rgb_buffer[2][x-1][y]+rgb_buffer[2][x-1][y+1]+
          			rgb_buffer[2][x][y-1]+rgb_buffer[2][x][y]+rgb_buffer[2][x][y+1]+
          			rgb_buffer[2][x+1][y-1]+rgb_buffer[2][x+1][y]+ rgb_buffer[2][x+1][y+1];
   	        	 
          	 Color c2 = new Color(r/9,g/9,b/9);
	        	 SmoothPic.setRGB(y, x, c2.getRGB());
	         }
	     }
	     
		 
		 
		 return SmoothPic;
	 }
	 
	 public static void main(String[] args) throws IOException 
	 {
    	 
		 SmoothingImage Smooth = new SmoothingImage("nature.jpg", "output");
		 Smooth.setSize(800, 600);
		 Smooth.setVisible(true);
		 Smooth.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    	
	   
	    }	
}
