
import java.awt.Color;

public class Fade2 {

    public static Color combine(Color c1, Color c2, double alpha)
    {
        int r = (int) (alpha * c1.getRed()   + (1 - alpha) * c2.getRed());
        int g = (int) (alpha * c1.getGreen() + (1 - alpha) * c2.getGreen());
        int b = (int) (alpha * c1.getBlue()  + (1 - alpha) * c2.getBlue());
        return new Color(r, g, b);
    }

    public static void main(String[] args) 
    {
    	
    	Picture picture1 = new Picture("cartoon1.jpg");   // begin picture
        Picture picture2 = new Picture("flower.jpg"); 
        Picture picture = new Picture(picture1.width(), picture1.height());
       
        
    	
    	int mMax=1;
        
        for(float m =0; m<=mMax; m = (float) (m + 0.01))
        {
           for(int i=0;i<picture.width();i++)
            {
                for(int j=0;j<picture.height();j++)
                {
                    Color c1 = picture1.get(i,j);
                    Color c2 = picture2.get(i,j);
                
                    picture.set(i, j, combine(c1, c2, m));
            
                }
            
            }
    	
   
            picture.show();
        }
    }
}