/*
 * Sharpenning of an Image
 * by Jannatun Nahar
 */
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JFrame;

public class SharpenningImage extends JFrame
{
	
	private static final long serialVersionUID = 1L;
	static int[][][] rgb_buffer;
	SharpenningImage(String in, String out)
	{
        super("..:: Sharpenning of an Image ::..");
try {
    this.setLayout(new GridLayout(1, 2, 10, 10));
    JPanel img1 = new JPanel();
    JPanel img2 = new JPanel();
    File f1 = new File(in);
    File f2 = new File(out);
    BufferedImage image1 = ImageIO.read(f1);
    img1.add(new JLabel(new ImageIcon(image1)));
    BufferedImage image2 = SharpenningProcess(image1);
    ImageIO.write(image2, "jpg", f2);
    img2.add(new JLabel(new ImageIcon(image2)));
    this.add(img1);
    this.add(img2);
} catch (Exception ex) {
    System.out.println(ex.getMessage());
}
 }
	
	 BufferedImage SharpenningProcess(BufferedImage src) 
	 {
		 BufferedImage SharpPic = new BufferedImage(src.getWidth(), src.getHeight(), BufferedImage.TYPE_3BYTE_BGR);
		 
		 rgb_buffer = new int[3][src.getHeight()][src.getWidth()];
	     for (int row = 0; row < src.getHeight(); row++) {
	         for (int col = 0; col <src.getWidth(); col++) { 	
	        	 Color c1= new Color(src.getRGB(col, row));     	 
	        	 rgb_buffer[0][row][col] =c1.getRed();
	        	 rgb_buffer[1][row][col] =c1.getGreen();
	        	 rgb_buffer[2][row][col] =c1.getBlue();  	 
	         }
	     }
         for (int row = 1; row < src.getHeight()-1; row++) {
	         for (int col = 1; col <src.getWidth()-1; col++) {
	        	 int r=0, g=0, b=0;
	       	 r = (int) (rgb_buffer[0][row][col]+ 5*(rgb_buffer[0][row][col] - rgb_buffer[0][row-1][col-1]));
	        	 g = (int) (rgb_buffer[1][row][col]+ 5*(rgb_buffer[1][row][col] - rgb_buffer[1][row-1][col-1]));
	        	 b = (int) (rgb_buffer[2][row][col]+ 5*(rgb_buffer[2][row][col] - rgb_buffer[2][row-1][col-1]));
	     	 if(r>255) {
	        		 r=255;
	        	 }
	        	 if(r<0) {
	        		 r=0;
	        	 }
	       	 if(g>255) {
	        		 g=255;
	        	 }
	        	 if(g<0) {
	        		 g=0;
	        	 }
	        	 
	        	 if(b>255) {
	        		 b=255;
	        	 }
	        	 if(b<0) {
	        		 b=0;
	        	 }     			
	        	 
	        	 Color c2 = new Color(r,g,b);
	        	 SharpPic.setRGB(col, row, c2.getRGB());
	        	 			  
	         }
	     }
	     
		 
		 
		 return SharpPic;
	 }
	 
	 public static void main(String[] args) throws IOException 
	 {
    	 
		 SharpenningImage Sharp = new SharpenningImage("scene.jpg", "output");
         Sharp.setSize(800, 600);
         Sharp.setVisible(true);
         Sharp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    	
	   
	    }	
}
