import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.image.BufferedImageOp;
import java.awt.image.ConvolveOp;
import java.awt.image.Kernel;

import algoritharium.Image;
import algoritharium.ImageViewer;

public class MyImageAlgorithms {
	public void oneRedDot() {
		Image img = ImageViewer.getImage();
		img.setPixelColor(20, 20, Color.RED);
	}

	public void lotRedDots() {

		Image img = ImageViewer.getImage();
		img.setPixelColor(20, 20, Color.RED);
		img.setPixelColor(21, 20, Color.RED);
		img.setPixelColor(22, 20, Color.RED);
		img.setPixelColor(23, 20, Color.RED);
	}

	public void loopRedDots() {
		Image img = ImageViewer.getImage();
		for (int i = 20; i <= 23; i++)
			img.setPixelColor(i, 20, Color.RED);
	}

	public void turnImageRed() {
		Image img = ImageViewer.getImage();
		for (int i = 0; i < img.getWidth(); i++)
			for (int j = 0; j < img.getHeight(); j++)
				img.setPixelColor(i, j, Color.RED);
	}

	public void redGreenCheckerboard1() {
		Image img = ImageViewer.getImage();
		Color[][] c = img.getPixelColors();
		Color currentColor = Color.red;
		for (int i = 0; i < c.length; i++) {
			if (i % 20 == 0)
				currentColor = changeColor1(currentColor);
			for (int j = 0; j < c[i].length; j++) {
				if (j % 20 == 0)
					currentColor = changeColor1(currentColor);
				c[i][j] = currentColor;
			}
		}
		img.setPixelColors(c);
	}

	public Color changeColor1(Color c) {
		if (c == Color.GREEN)
			return Color.red;
		else
			return Color.green;
	}

	public void redGreenCheckerboard() {
		Image img = ImageViewer.getImage();
		Color[][] c = img.getPixelColors();
		Color currentColor = Color.red;
		for (int i = 0; i < c.length; i++) {
			if (i % 20 == 0)
				currentColor = changeColor1(currentColor);
			for (int j = 0; j < c[i].length; j++) {
				if (j % 20 == 0)
					currentColor = changeColor1(currentColor);
				c[i][j] = currentColor;
			}
		}
		img.setPixelColors(c);
	}

	public Color changeColor(Color c) {
		if (c == Color.GREEN)
			return Color.red;
		else
			return Color.green;
	}

	public void redFilter() {
		Image img = ImageViewer.getImage();
		Color c1, c2;

		for (int i = 0; i < img.getWidth(); i++)
			for (int j = 0; j < img.getHeight(); j++) {
				c1 = img.getPixelColor(i, j);
				c2 = new Color(c1.getRed(), 0, 0);
				img.setPixelColor(i, j, c2);
			}
	}

	public void getRGB() {
	}

	public void setRGB() {
	}

	public void GrayScale() {
		Image img = ImageViewer.getImage();
		Color[][] c = img.getPixelColors();
		Color currentColor;
		for (int i = 0; i < c.length; i++) {
			for (int j = 0; j < c[i].length; j++) {
				currentColor = new Color(((c[i][j].getRed() + c[i][j].getBlue() + c[i][j].getGreen()) / 3),
						((c[i][j].getRed() + c[i][j].getBlue() + c[i][j].getGreen()) / 3),
						((c[i][j].getRed() + c[i][j].getBlue() + c[i][j].getGreen()) / 3));
				c[i][j] = currentColor;
			}
		}
		img.setPixelColors(c);
	}

	public void negative() {
		Image img = ImageViewer.getImage();
		Color[][] c = img.getPixelColors();
		Color currentColor;
		for (int i = 0; i < c.length; i++) {
			for (int j = 0; j < c[i].length; j++) {
				currentColor = new Color(255 - c[i][j].getBlue(), 255 - c[i][j].getGreen(), 255 - c[i][j].getRed());
				c[i][j] = currentColor;
			}
		}
		img.setPixelColors(c);
	}

	public void paintBorder(Component c) {
		Graphics g;
		int x;
		int y;
		int width1;
		int height1;
	}

	public void rotate() {
		Image img = ImageViewer.getImage();
		Color[][] c = img.getPixelColors();
		int width = c.length;
		int height = c[0].length;
		double angle = Math.toRadians(Double.parseDouble("180"));
		double sin = Math.sin(angle);
		double cos = Math.cos(angle);
		// double x0 = 0.5 * (width - 1); // point to rotate about
		// double y0 = 0.5 * (height - 1); // center of image
		double x0 = 0.5 * (width - 1); // point to rotate about
		double y0 = 0.5 * (height - 1); // center of image
		for (int i = 0; i < c.length; i++) {
			for (int j = 0; j < c[i].length; j++) {
				width = c.length;
				height = c[i].length;

				double a = i - x0;
				double b = j - y0;
				int xx = (int) (+a * cos - b * sin + x0);
				int yy = (int) (+a * sin + b * cos + y0);

				// plot pixel (x, y) the same jor as (xx, yy) if it's in bounds
				// if (xx >= 0 && xx < width && yy >= 0 && yy < height) {
				// c[i][j] = c[xx][yy];
				// }
				try {
					c[i][j] = c[xx][yy];
				} catch (Exception e) {

				}
			}
		}
		img.setPixelColors(c);
	}

	public void edgeDetection() {
		Image img = ImageViewer.getImage();
		Color[][] c = img.getPixelColors();
		Color currentColor;
		int edgeDist = 50;
		Color leftColor = null;
		Color rightColor = null;
		Color bottomColor = null;
		boolean black;

		for (int i = 0; i < c.length; i++) {
			for (int j = 0; j < c[i].length; j++) {
				black = false;
				leftColor = c[i][j];
				if (j < c[0].length - 1) {
					rightColor = c[i][j + 1];
					if (distance(leftColor, rightColor) < edgeDist)
						black = true;
				}
				if (i < c.length - 1) {
					bottomColor = c[i + 1][j];
					if (distance(leftColor, bottomColor) < edgeDist)
						black = true;

				}
				if (black) {
					c[i][j] = Color.black;
					// leftColor.getColor(Color.BLACK);
				} else {
					c[i][j] = Color.white;
					// leftColor.setColor(Color.WHITE);
				}
			}
		}
		img.setPixelColors(c);

	}

	public void blur() {
		Image img = ImageViewer.getImage();
		// create buffered image
		BufferedImage bimage = new BufferedImage(img.getWidth(), img.getHeight(), BufferedImage.TYPE_INT_ARGB);
		// Draw the image on to the buffered image
		Graphics2D bGr = bimage.createGraphics();
		bGr.drawImage((java.awt.Image) img, 0, 0, null);
		bGr.dispose();
		// blur
		Kernel kernel = new Kernel(3, 3,
				new float[] { 1f / 9f, 1f / 9f, 1f / 9f, 1f / 9f, 1f / 9f, 1f / 9f, 1f / 9f, 1f / 9f, 1f / 9f });
		BufferedImageOp op = new ConvolveOp(kernel);
		bimage = op.filter(bimage, null);

		Color[][] c = img.getPixelColors();
		Color currentColor;
		for (int i = 0; i < c.length; i++) {
			for (int j = 0; j < c[i].length; j++) {
				c[i][j] = new Color(bimage.getRGB(i, j));
			}
		}
		img.setPixelColors(c);

	}

	double distance(Color c1, Color c2) {
		return (c1.getRed() - c2.getRed()) * (c1.getRed() - c2.getRed())
				+ (c1.getGreen() - c2.getGreen()) * (c1.getGreen() - c2.getGreen())
				+ (c1.getBlue() - c2.getBlue()) * (c1.getBlue() - c2.getBlue());
	}
}
